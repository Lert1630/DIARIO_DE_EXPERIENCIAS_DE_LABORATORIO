﻿using System;

namespace L_R_ACTIVIDAD1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese nombre: ");
            String nombre = Console.ReadLine();
            Console.WriteLine("Ingrese edad: ");
            String Edad = Console.ReadLine();
            Console.WriteLine("Ingrese carrera: ");
            String carrera = Console.ReadLine();
            Console.WriteLine("Ingrese carne: ");
            String Carne = Console.ReadLine();

            Console.WriteLine("Hola");
            Console.WriteLine("soy " + nombre + "tengo " + Edad + "años y estudio la carrera de "+ carrera + "mi numero de carne es " + Carne);
            Console.ReadKey();

        }
    }
}
